"""Validaciones y detectores MeteoSer."""
