# ✅ Checklist de Seguridad/Eficiencia de Automatismos

Fecha: 2026-02-04

Objetivo: auditar **detección automática de nuevas fórmulas**, **optimización** y **automatismos** para precisión, estabilidad, fluidez, consistencia y eficiencia.

---

## 1) Detección automática de nuevas fórmulas (Vanguard Ojeador)
**Archivos:**
- core/monitoring/vanguard_ojeador.py

### ✅ Fortalezas
- Escaneo con límites de tiempo (MAX_SCAN_SECONDS, MAX_SOURCE_SECONDS).
- Persistencia de estado y alertas.
- Comparación de precisión vs fórmula actual (no sugiere si no mejora).

### ⚠️ Riesgos
- Heurística amplia en _is_formula_function() puede producir falsos positivos.
- Fuentes externas pueden traer ruido (resúmenes imprecisos).
- No valida compatibilidad exacta de parámetros antes de sugerir.

### ✅ Mitigaciones existentes
- Solo sugiere mejoras si precisión numérica es mejor.
- No aplica cambios automáticamente.

### ✅ Recomendación
- Añadir verificación de requisitos de datos antes de sugerir.
- Limitar a categorías con datos suficientes en el bus.

Estado: **Seguro con mitigaciones** (no aplica cambios automáticamente).

---

## 2) Registro de candidatas (FormulaCandidateRegistry)
**Archivo:**
- core/monitoring/formula_candidate_registry.py

### ✅ Fortalezas
- Persistencia en JSON, no toca producción directamente.
- Resolución por alias y por id.

### ⚠️ Riesgos
- No normaliza inputs canónicos antes de usar.
- Falta validación de firma/parametros al agregar candidatas.

### ✅ Mitigaciones existentes
- No aplica cambios automáticamente.

### ✅ Recomendación
- Normalizar inputs con parámetros canónicos antes de guardar.

Estado: **Bajo riesgo**.

---

## 3) Motor de duelos + auto‑mejora
**Archivos:**
- core/monitoring/formula_duel_engine.py
- core/monitoring/formula_optimizer.py

### ✅ Fortalezas
- Auto‑mejora es **simulada** (no modifica fórmula original).
- Robustez integrada en scoring.
- No hay efectos en cascada (reversibilidad demostrada en tests).

### ⚠️ Riesgos
- Si la muestra histórica está sesgada, el score puede estar sesgado.
- Requiere histórico limpio (se filtra, pero depende de calidad de datos).

### ✅ Mitigaciones existentes
- Filtro de histórico limpio.
- Penaliza robustez cuando hay errores.

### ✅ Recomendación
- Añadir alertas si el tamaño muestral es muy bajo.

Estado: **Seguro y estable** (auto‑mejora no persiste cambios).

---

## 4) Watchdog de cambios
**Archivo:**
- core/monitoring/auto_change_watchdog.py

### ✅ Fortalezas
- Rollback automático con circuit breaker.
- Validación proactiva no bloqueante (solo warnings).

### ⚠️ Riesgos
- Si los umbrales son demasiado laxos, puede dejar pasar degradación leve.

### ✅ Recomendación
- Revisar thresholds periódicamente.

Estado: **Seguro**.

---

## 5) Normalización canónica (auto‑corrección total)
**Archivo:**
- core/bus/parametros_canonicos.py

### ✅ Fortalezas
- Alias canónicos persistentes (data/param_aliases.json).
- Corrección automática sin bloqueo.

### ⚠️ Riesgos
- Un alias mal resuelto puede quedar persistente.

### ✅ Mitigación
- Persistencia solo en alias nuevos; se puede limpiar el JSON.

Estado: **Eficiente y estable**.

---

# ✅ Conclusión Global
- **No es 100% sin riesgo**, pero está **muy controlado**.
- Los sistemas automáticos **no aplican cambios críticos** sin validación.
- La auto‑mejora es **simulada** y reversible.
- La autocorrección **no bloquea**, corrige y persiste.

**Resultado:** Seguro con mitigaciones; riesgo residual bajo.

---

# ✅ Acciones recomendadas (opcionales)
1. Normalizar inputs en FormulaCandidateRegistry.
2. Verificar requisitos de datos en Vanguard antes de sugerir.
3. Añadir alertas por baja muestra en duelos.
4. Revisar thresholds del watchdog cada 30 días.
