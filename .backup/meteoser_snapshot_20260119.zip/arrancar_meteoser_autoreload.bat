@echo off
REM Script de arranque automático con autorecarga para MeteoSer
cd /d %~dp0

REM Cierra cualquier proceso en el puerto 8080 (opcional, solo si hay conflicto)
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :8080') do taskkill /F /PID %%a >nul 2>&1

REM Arranca el backend con autoreload
start "MeteoSer Backend" cmd /k uvicorn main_asgi:app --host 0.0.0.0 --port 8080 --reload

echo MeteoSer backend arrancado con autorecarga.
echo Puedes cerrar esta ventana, el backend seguirá funcionando.
pause
