from meteo_interface import MeteoSerInterface

# Mocks mínimos para demo funcional




