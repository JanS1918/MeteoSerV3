@echo off
"C:\Users\kioko\Downloads\nssm-2.24-101-g897c7ad\nssm-2.24-101-g897c7ad\win64\nssm.exe" restart MeteoSer
pause