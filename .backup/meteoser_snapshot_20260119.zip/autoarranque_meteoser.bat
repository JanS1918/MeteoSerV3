@echo off
REM Script para autoarranque de MeteoSer al iniciar sesión en Windows
cd /d %~dp0
start "MeteoSer" python arrancar_meteoser.py
