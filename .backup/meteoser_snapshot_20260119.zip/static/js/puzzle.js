// puzzle.js: carga dinámica para interfaz tipo puzzle MeteoSer

function setContent(id, text) {
    const el = document.getElementById(id + '-content');
    if (el) el.textContent = text;
}

// Ejemplo de carga simulada (reemplazar por fetch real a la API)
document.addEventListener('DOMContentLoaded', () => {
    setContent('estado', 'Sistema operativo y estable');
    setContent('sensores', 'Temp: 22°C\nHumedad: 45%');
    setContent('indices', 'Índice confort: Óptimo');
    setContent('prediccion', 'Sin lluvias próximas');
    setContent('recomendaciones', 'Ventila la casa por la mañana');
    setContent('historial', 'Última acción: Ventilación activada');
    setContent('noticias', 'Sin noticias relevantes');
    setContent('asistente', '¿En qué puedo ayudarte?');
    setContent('configuracion', 'Modo: Automático');
});
